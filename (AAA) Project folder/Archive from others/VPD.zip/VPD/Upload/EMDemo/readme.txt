This is the code for vanishing point detection algorithm proposed by
J. Kosecka and W. Zhang. Video compass. Proc. European Conference on Computer Vision, pp. 657-673, 2002.

******Please cite the paper if you use it.*******

Use the code at your own risk. 

The code has been tested under Ubuntu Linux 9.04 with Matlab 2009a.

demo.m provides an example of how to use the code. 
