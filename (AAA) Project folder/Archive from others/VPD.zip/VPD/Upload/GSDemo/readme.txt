This is the code for vanishing point detection algorithm proposed by
S. T. Barnard. Interpreting perspective images. Artificial Intelligence, vol. 21, pp. 435-462, 1983.

******Please cite the paper if you use it.*******

Use the code at your own risk. 

The code has been tested under Ubuntu Linux 9.04 with Matlab 2009a.

demo.m provides an example of how to use the code. 
